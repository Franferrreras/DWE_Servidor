package Main;

public class TejadoTejas extends Tejado{

	@Override
	public void darSoporte() {
		// TODO Auto-generated method stub
		System.out.println("Soy un tejado de tejas que da soporte");
	}

	
	
}
