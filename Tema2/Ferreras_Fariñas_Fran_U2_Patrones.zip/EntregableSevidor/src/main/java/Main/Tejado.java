package Main;

public class Tejado {

	public void darSoporte() {
		System.out.println("Estoy dando soporte a la casa");
	}
}
