package Main;

public class Main {

	public static void main(String[] args) {

		// Casa1
		Tejado tj1 = new Tejado();
		Pared prd1 = new Pared(20.5);
		Pared prd2 = new Pared(20.5);
		Pared prd3 = new Pared(20.5);
		Pared prd4 = new Pared(20.5);

		Casa cs1 = new Casa("80 m2", tj1, prd1, prd2, prd3, prd4);

		// Casa 2
		Tejado tj2 = new TejadoTejas();
		Pared prd5 = new Pared(18.5);
		Pared prd6 = new Pared(18.5);
		Pared prd7 = new Pared(18.5);
		Pared prd8 = new Pared(18.5);

		Casa cs2 = new Casa("90 m2", tj2, prd5, prd6, prd7, prd8);

		tj1.darSoporte();
		System.out.println(cs1);

		System.out.println(cs2);
		tj2.darSoporte();
	}
}
