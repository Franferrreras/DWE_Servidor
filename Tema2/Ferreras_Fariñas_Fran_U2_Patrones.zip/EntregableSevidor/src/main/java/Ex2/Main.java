package Ex2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Figura figura = FactoryFiguras.dibujarFigura("triangulo", "amarillo");
		Figura figura2 = FactoryFiguras.dibujarFigura("cuadrado", "Azul");
		Figura figura3 = FactoryFiguras.dibujarFigura("circulo", "Morado");
		Figura figura4 = FactoryFiguras.dibujarFigura("rectangulo", "Marron");

		figura.dibujarFigura();
		figura2.dibujarFigura();
		figura3.dibujarFigura();
		figura4.dibujarFigura();
	}

}
