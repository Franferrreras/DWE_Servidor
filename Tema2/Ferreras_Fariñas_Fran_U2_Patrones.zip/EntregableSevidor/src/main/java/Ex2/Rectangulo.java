package Ex2;

public class Rectangulo extends Figura{

	public Rectangulo(String color) {
		super(color);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void dibujarFigura() {
		// TODO Auto-generated method stub
		System.out.println("Estoy dibujando un rectangulo de color " + Rectangulo.super.getColor());
		
	}

	
}
