package Ex2;

public class FactoryFiguras {
	
	public static Figura dibujarFigura(String figura, String color) {
		
		if (figura.equals("cuadrado")) {
			return new Cuadrado(color);
		} else if (figura.equals("triangulo")) {
			return new Triangulo(color);
		} else if (figura.equals("circulo")) {
			return new Circulo(color);
		} else if (figura.equals("rectangulo")) {
			return new Rectangulo(color);
		} else {
			System.out.println("Esa figura no existe");
			return null;
		}
	}
}
