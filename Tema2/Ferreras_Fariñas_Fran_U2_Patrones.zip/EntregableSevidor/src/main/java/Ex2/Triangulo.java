package Ex2;

public class Triangulo extends Figura{

	public Triangulo(String color) {
		super(color);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void dibujarFigura() {
		System.out.println("Estoy dibujando un triangulo de color " + Triangulo.super.getColor());
		
	}

}
