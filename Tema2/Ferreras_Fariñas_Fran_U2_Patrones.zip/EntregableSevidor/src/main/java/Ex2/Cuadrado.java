package Ex2;

public class Cuadrado extends Figura{

	public Cuadrado(String color) {
		super(color);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void dibujarFigura() {
		// TODO Auto-generated method stub
		System.out.println("Estoy dibujando un cuadrado de color " + Cuadrado.super.getColor());
	}

	
}
