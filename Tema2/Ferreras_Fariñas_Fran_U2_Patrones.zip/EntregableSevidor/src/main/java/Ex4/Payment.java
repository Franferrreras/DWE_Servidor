package Ex4;

public class Payment {
	
	private int customerNumber;
	private String checkNumber;
	private String paymentDate;
	private double amount;
	
	public Payment(int customerNumber, String checkNumger, String paymentDate, double amount) {
		super();
		this.customerNumber = customerNumber;
		this.checkNumber = checkNumger;
		this.paymentDate = paymentDate;
		this.amount = amount;
	}

	public int getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(int customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumger) {
		this.checkNumber = checkNumger;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Payment [customerNumber=" + customerNumber + ", checkNumger=" + checkNumber + ", paymentDate="
				+ paymentDate + ", amount=" + amount + "]" + "\n";
	}
	
	

}
