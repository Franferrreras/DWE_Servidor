package Ex4;

import java.util.List;

public interface DaoPayment {

	
	List<Payment> getPayment();
	
	void createPayment(Payment payment);
	
	
}
