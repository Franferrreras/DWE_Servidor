package Ex4;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DaoPaymentsImplementations implements DaoPayment {

	public List<Payment> getPayment() {
		// TODO Auto-generated method stub

		Connection connection = ConexionDB.getConnection();
		List<Payment> listPayment = new ArrayList<Payment>();

		try {
			String sql = "SELECT * FROM payments";
			PreparedStatement statement = connection.prepareStatement(sql);

			ResultSet rs = statement.executeQuery();

			while (rs.next()) {

				Payment e = new Payment(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
				listPayment.add(e);

			}
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}

		return listPayment;
	}

	public void createPayment(Payment payment) {
		// TODO Auto-generated method stub

		Connection connection = ConexionDB.getConnection();

		if (comprobarExistCustomer(payment)) {
			try {
				String sql = "INSERT INTO payments VALUES(?, ?, ?, ?)";
				PreparedStatement statement = connection.prepareStatement(sql);

				statement.setInt(1, payment.getCustomerNumber());
				statement.setString(2, payment.getCheckNumber());
				statement.setString(3, payment.getPaymentDate());
				statement.setDouble(4, payment.getAmount());
				
				statement.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		} else {
			System.out.println("El payment que intenta insertar ya existe");
		}

	}

	public static boolean comprobarExistCustomer(Payment payment) {
		Connection connection = ConexionDB.getConnection();
		int count = 0;
		
		try {

			String sql = "SELECT * FROM payments WHERE customerNumber=?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, payment.getCustomerNumber());

			ResultSet rs = statement.executeQuery();

			while (rs.next()) {
				count++;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count > 0) {
			return false;
		} else {
			return true;
		}

	}

//	public static void main(String[] args) {
//		Connection connection = ConexionDB.getConnection();
//		// Inserción de categira y dos nuesvos productos
//		try {
//			connection.setAutoCommit(false);
//			DaoPaymentImplementation.insertPayments();
//			connection.commit();
//			connection.close();
//		} catch (SQLException throwables) {
//			throwables.printStackTrace();
//			try {
//				if (connection != null) {
//					connection.rollback();
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		}
//	}

//	public static List<Payment> MostrarPayment(String customerNumber) {
//		Connection connection = ConexionDB.getConnection();
//		List<Payment> listPayment = new ArrayList<Payment>();
//
//		try {
//			String sql = "SELECT * FROM employees WHERE customerNumber=?";
//			PreparedStatement statement = connection.prepareStatement(sql);
//			statement.setString(1, customerNumber);
//
//			ResultSet rs = statement.executeQuery();
//
//			while (rs.next()) {
//				Payment e = new Payment(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
//				listPayment.add(e);
//			}
//		} catch (SQLException throwables) {
//			throwables.printStackTrace();
//		}
//
//		return listPayment;
//	}

}
