package Ex4;

import java.sql.Connection;
import java.sql.SQLException;

public class Main {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		Connection connection = ConexionDB.getConnection();
		
		Payment payment = new Payment(600, "BMWXYZ7", "2000-01-01", 38570.50);
		
		
		DaoPaymentsImplementations daoPaymentIm = new DaoPaymentsImplementations();
		
		//System.out.println(daoPaymentIm.getPayment());
		
		
		daoPaymentIm.createPayment(payment);
		
		
		//daoPayment.createPayment(payment);
		
		connection.close();

	}

}
